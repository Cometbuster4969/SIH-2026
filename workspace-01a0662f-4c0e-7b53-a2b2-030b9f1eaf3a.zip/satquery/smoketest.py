# Quick end-to-end smoke test against a running server.
#   python smoketest.py   (or: bash smoketest.sh)

from __future__ import annotations

import json

import httpx

BASE = "http://localhost:8000"
QUERIES = [
    "Describe the land-cover and major objects visible in this image.",
    "What changed between these two dates, and where?",
    "Has the built-up area increased, decreased, or remained unchanged?",
]


def main():
    c = httpx.Client(base_url=BASE, timeout=60)
    assert c.get("/health").json()["status"] == "ok"
    tools = c.get("/api/v1/tools").json()
    assert "vqa" in tools["registry"]
    d = c.post("/api/v1/demo/load").json()
    rid = d["request_id"]
    print(f"loaded request {rid}  pair={d['inventory']['pair']['type']}")
    for q in QUERIES:
        r = c.post("/api/v1/query", json={"request_id": rid, "query": q}).json()
        print(f"{r['status']:8s} {r.get('task'):12s} conf={r.get('confidence')}")
        print(f"          {r.get('final_answer')}")
        print(f"          trace: {[t['tool'] for t in r.get('trace', [])]}")
    print("all good")


if __name__ == "__main__":
    main()
