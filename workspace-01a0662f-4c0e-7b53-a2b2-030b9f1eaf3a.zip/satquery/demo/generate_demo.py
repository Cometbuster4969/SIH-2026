# Generates a small set of curated demo scenes (PNG stand-ins for GeoTIFFs) so the
# whole pipeline can be exercised before real RS tiles exist. Deterministic.
#   usage: python -m demo.generate_demo   (run from repo root)

from __future__ import annotations

import os

import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "data")
OUT = os.path.join(os.path.dirname(__file__), "data", "demo")
os.makedirs(OUT, exist_ok=True)


def _scene(seed: int, kind: str, size: int = 512) -> np.ndarray:
    rng = np.random.default_rng(seed)
    base = np.zeros((size, size, 3), np.uint8)
    base[..., :] = (60, 90, 60) if kind != "water" else (40, 70, 120)
    # parcels
    for _ in range(14):
        x, y = rng.integers(0, size - 60), rng.integers(0, size - 60)
        c = tuple(int(v) for v in rng.integers(40, 160, 3))
        base[y:y + rng.integers(30, 70), x:x + rng.integers(30, 90)] = c
    # built-up rectangles
    for _ in range(6):
        x, y = rng.integers(0, size - 30), rng.integers(0, size - 30)
        base[y:y + 18, x:x + 18] = (150, 150, 150)
    # road
    base[size // 2, :] = (220, 220, 220)
    return base


def _write(name: str, arr: np.ndarray) -> str:
    # Save as GeoTIFF-mimicking TIFF so the demo assets pass the ingestion format
    # gate (PNG is only allowed for benchmark-dataset dirs, per the PS input scope).
    name = name.replace(".png", ".tif")
    p = os.path.join(OUT, name)
    Image.fromarray(arr).save(p, format="TIFF")
    return p


def main() -> dict:
    scenes = {}
    # Single optical (a.k.a. t1) and a later optical (t2) -> bi-temporal pair.
    scenes["single_optical"] = _write("single_optical.png", _scene(1, "land"))
    scenes["t1_optical"] = _write("t1_optical.png", _scene(2, "land"))
    t2 = _scene(3, "land")
    t2[240:300, 200:280] = (170, 150, 150)  # new built-up (the "change")
    scenes["t2_optical"] = _write("t2_optical.png", t2)
    scenes["single_sar"] = _write("single_sar.png", _scene(4, "sar_placeholder"))
    scenes["sar"] = _write("sar.png", _scene(5, "water"))
    print(f"Wrote demo scenes to {OUT}")
    return scenes


if __name__ == "__main__":
    main()
