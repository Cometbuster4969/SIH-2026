# Integration tests against the FastAPI app (uses TestClient / ASGI transport).

from __future__ import annotations

import os
import sys

import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["SATQUERY_DB"] = ":memory:"

from backend.api.app import app  # noqa: E402

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_tools_exposes_registry():
    r = client.get("/api/v1/tools")
    assert r.status_code == 200
    body = r.json()
    assert "vqa" in body["registry"] and "change_map" in body["registry"]
    assert "CAPTION" in body["tasks"]


def test_demo_load_and_query_flow():
    # Load demo bi-temporal pair.
    r = client.post("/api/v1/demo/load")
    assert r.status_code == 200
    data = r.json()
    rid = data["request_id"]
    assert data["inventory"]["pair"]["type"] == "bi_temporal"

    # Ask a change query.
    r2 = client.post("/api/v1/query", json={"request_id": rid,
                                            "query": "What changed between these two dates, and where?"})
    assert r2.status_code == 200
    res = r2.json()
    assert res["status"] == "DONE"
    assert res["final_answer"]
    tools = [t["tool"] for t in res["trace"]]
    assert "change_map" in tools and "integrate" in tools

    # Trace artifact retrievable.
    r3 = client.get(f"/api/v1/requests/{rid}/trace.json")
    assert r3.status_code == 200
    assert r3.json()["task"]
    assert r3.json()["steps"]


def test_format_reject_for_non_benchmark_png(tmp_path):
    # Upload a PNG that is NOT in a benchmark dir -> should be rejected with E_FORMAT.
    p = tmp_path / "plain.png"
    Image.fromarray(np.zeros((64, 64, 3), np.uint8)).save(p)
    with open(p, "rb") as fh:
        r = client.post("/api/v1/ingest", files=[("files", ("plain.png", fh, "image/png"))])
    assert r.status_code == 400
    assert "E_FORMAT" in str(r.json())
