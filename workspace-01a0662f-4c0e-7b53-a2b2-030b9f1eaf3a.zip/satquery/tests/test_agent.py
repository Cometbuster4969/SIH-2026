# Unit tests for the agent core: registry, planner, guardrail, fallback, executor,
# integrator, confidence aggregation. These run with zero ML deps.

from __future__ import annotations

import os

import numpy as np
import pytest
from PIL import Image

from backend.agent.guardrail import validate
from backend.agent.integrator import aggregate_confidence
from backend.agent.planner import RulePlanner, infer_intent, infer_task
from backend.agent.rulerouter import fallback_plan
from backend.agent.schemas import Plan, Step
from backend.agent.registry import registry, TASKS, SCOPE_ALLOWED_TASKS
from backend.orchestrator import Orchestrator
from backend.store.trace import TraceStore


def _tmp_img(tmp_path, name="img.png"):
    p = str(tmp_path / name)
    Image.fromarray(np.zeros((512, 512, 3), np.uint8)).save(p)
    return p


def _inventory_single(img):
    return {"request_id": "r1", "pair": {"type": "single_optical"},
            "files": [{"path": img, "modality": "optical"}]}


def _inventory_bi(img1, img2):
    return {"request_id": "r2", "pair": {"type": "bi_temporal"},
            "files": [{"path": img1, "modality": "optical"},
                      {"path": img2, "modality": "optical"}]}


def _inventory_xmodal(img1, img2):
    return {"request_id": "r3", "pair": {"type": "cross_modal"},
            "files": [{"path": img1, "modality": "optical"},
                      {"path": img2, "modality": "sar"}]}


# ---- registry -----------------------------------------------------------
def test_registry_wellformed():
    for name, spec in registry.items():
        assert name in "vqa caption ground change_map change_vqa xmodal_caption xmodal_vqa xmodal_mask integrate".split()
        assert spec["version"]
        assert isinstance(spec["whitelist"], list)


def test_task_taxonomy_covers_scopes():
    assert set(TASKS) >= {"CAPTION", "VQA", "GROUND", "CHANGE_VQA", "XMODAL_MASK", "MULTI_STEP"}


# ---- intent / task inference -------------------------------------------
@pytest.mark.parametrize("q,intent", [
    ("Describe the land-cover", "describe"),
    ("What objects are visible?", "ask"),
    ("Highlight the water body", "highlight"),
    ("Has built-up increased?", "trend"),
    ("Identify built-up and water", "classify"),
])
def test_intent(q, intent):
    assert infer_intent(q) == intent


@pytest.mark.parametrize("scope,intent", [
    ("bi_temporal", "describe"),
    ("cross_modal", "classify"),
    ("single_optical", "highlight"),
])
def test_task_in_scope(scope, intent):
    task = infer_task(intent, scope)
    assert task in SCOPE_ALLOWED_TASKS[scope]


# ---- planner + guardrail ------------------------------------------------
def test_rule_plan_valid_for_bi_temporal(tmp_path):
    inv = _inventory_bi(_tmp_img(tmp_path, "a.png"), _tmp_img(tmp_path, "b.png"))
    plan = RulePlanner().plan("What changed between these two dates?", inv)
    ok, reason = validate(plan, inv)
    assert ok, reason
    assert plan.task == "CHANGE_VQA" or plan.task == "CHANGE_DESC"
    assert plan.steps[-1].tool == "integrate"


def test_rule_plan_rejects_disallowed_param(tmp_path):
    inv = _inventory_single(_tmp_img(tmp_path, "a.png"))
    plan = Plan(task="VQA", steps=[Step(id=1, tool="vqa", params={"evil": 1})],
                planner={})
    ok, _ = validate(plan, inv)
    assert not ok


def test_fallback_stamps_flag(tmp_path):
    inv = _inventory_single(_tmp_img(tmp_path, "a.png"))
    plan = fallback_plan("What is the dominant cover?", inv)
    assert plan.planner["fallback_used"] is True
    ok, reason = validate(plan, inv)
    assert ok, reason


def test_dependency_cycle_rejected(tmp_path):
    inv = _inventory_single(_tmp_img(tmp_path, "a.png"))
    plan = Plan(task="VQA", steps=[Step(id=1, tool="vqa", depends_on=[2]),
                                    Step(id=2, tool="vqa", depends_on=[1])],
                planner={})
    ok, reason = validate(plan, inv)
    assert not ok


# ---- executor + orchestrator -------------------------------------------
def test_orchestrator_end_to_end_bi(tmp_path):
    store = TraceStore(":memory:")
    orch = Orchestrator(store)
    inv = _inventory_bi(_tmp_img(tmp_path, "a.png"), _tmp_img(tmp_path, "b.png"))
    res = orch.run("r2", "What changed between these two dates, and where?", inv)
    assert res["status"] == "DONE"
    assert res["final_answer"]
    assert res["confidence"] > 0
    tools = [r["tool"] for r in res["trace"]]
    assert "change_map" in tools and "integrate" in tools
    # The trace was persisted.
    assert store.get_request("r2") is not None


def test_orchestrator_cross_modal_masks(tmp_path):
    store = TraceStore(":memory:")
    orch = Orchestrator(store)
    inv = _inventory_xmodal(_tmp_img(tmp_path, "o.png"), _tmp_img(tmp_path, "s.png"))
    res = orch.run("r3", "Use optical and SAR together to identify built-up and water.", inv)
    assert res["status"] == "DONE"
    assert any(r["tool"] == "xmodal_mask" for r in res["trace"])


def test_orchestrator_never_crashes_on_bad_scope(tmp_path):
    # A scope with no allowed task shouldn't crash; it should reject gracefully.
    store = TraceStore(":memory:")
    orch = Orchestrator(store)
    inv = {"request_id": "x", "pair": {"type": "invalid"},
           "files": []}
    res = orch.run("x", "anything", inv)
    assert res["status"] in ("DONE", "REJECTED")


# ---- confidence ---------------------------------------------------------
def test_confidence_badges():
    from backend.agent.schemas import TraceRow
    rows = [
        TraceRow(seq=1, tool="change_map", version="v", confidence=0.87, latency_ms=1),
        TraceRow(seq=2, tool="change_vqa", version="v", confidence=0.81, latency_ms=1),
    ]
    agg = aggregate_confidence([r for r in rows])
    assert agg["badge"] == "High"
    assert 0 < agg["confidence"] <= 1
