# Tool invocation layer.
#
# Every tool is a small callable that:
#   1. takes validated inputs (subset of the registry contract),
#   2. returns a normalized output dict (the ToolOutput contract),
#   3. NEVER raises on degraded inputs (returns lower confidence),
#   4. records its own latency + a stable version string.
#
# The tool name -> callable mapping lives in TOOLS below. The executor dispatches
# purely on this dict, so the agent never knows/cares how a tool is implemented.
#
# >>> TEAM: this file is the ONLY place you edit to plug in real models.
# >>> Replace the body of each stub fn (marked TOREPLACE) with a call to the real
# >>> model, keeping the SAME input dict keys and the SAME output dict keys.

from __future__ import annotations

import hashlib
import time
from typing import Any, Callable, Dict

import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# Deterministic synthetic helpers (TEMPORARY — replace with real inference).
# These produce *plausible* structured outputs so the whole system runs & demos
# end-to-end before any model weights exist. They are keyed on content hashes so
# the same image always yields the same output (useful for tests/demo replay).
# ---------------------------------------------------------------------------


def _seed_for(*paths: str) -> int:
    h = hashlib.sha256()
    for p in paths:
        h.update(p.encode())
    return int(h.hexdigest()[:8], 16)


def _rng(*paths: str) -> np.random.Generator:
    return np.random.default_rng(_seed_for(*paths))


def _load_im(path: str) -> np.ndarray:
    try:
        return np.asarray(Image.open(path).convert("RGB"))
    except Exception:
        return np.zeros((512, 512, 3), dtype=np.uint8)


def _write_mask(path: str, t1: str, t2: str, fill: float = False) -> str:
    """Synthesize a binary change/class mask as an 8-bit PNG at `path`."""
    rng = _rng(t1, t2)
    h, w = 256, 256
    base = (rng.random((h, w)) < 0.2).astype(np.uint8) * 255 if not fill else np.full((h, w), 255, np.uint8)
    Image.fromarray(base).save(path)
    return path


# ---------------------------------------------------------------------------
# Stub tool implementations. TOREPLACE the body of each with real inference.
# ---------------------------------------------------------------------------


def tool_vqa(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: `model.answer(image=inputs['image'], question=inputs['question'])`
    q = inputs.get("question", "")
    ans = "Stub answer. Dominant visual content is built-up land along the northern corridor."
    if any(w in q.lower() for w in ["water", "river", "lake", "water body"]):
        ans = "Stub answer. A water body is visible in the southwest quadrant."
    conf = float(np.clip(_rng(inputs["image"], q).random() * 0.15 + 0.80, 0, 1))
    return {"answer": ans, "answer_type": "open", "confidence": round(conf, 3)}


def tool_caption(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: RS-VLM caption head.
    img = inputs["image"]
    facts = {
        "landcover": "mixed agricultural and built-up",
        "objects": ["buildings", "road network", "field parcels"],
    }
    caption = (
        "Stub caption: this image shows a mixed-landscape scene with scattered built-up "
        "structures, a road network, and adjoining agricultural parcels."
    )
    conf = round(float(np.clip(_rng(img).random() * 0.15 + 0.80, 0, 1)), 3)
    return {"caption": caption, "facts": facts, "confidence": conf}


def tool_ground(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: Grounding-DINO-T fine-tuned box detector, NMS, stitch to full-frame.
    phrase = inputs.get("phrase", "")
    rng = _rng(inputs["image"], phrase)
    n = 2
    boxes = [
        {
            "xywh": [round(float(rng.random() * 350 + 20), 1) for _ in range(4)],
            "score": round(float(rng.random() * 0.3 + 0.6), 3),
            "label": phrase or "object",
        }
        for _ in range(n)
    ]
    conf = round(float(np.clip(rng.random() * 0.2 + 0.60, 0, 1)), 3)
    return {"boxes": boxes, "confidence": conf}


def tool_change_map(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: BiT/ChangeFormer on img_t1, img_t2 -> binary mask + transition facts.
    t1, t2 = inputs["img_t1"], inputs["img_t2"]
    thr = float(inputs.get("thr", 0.5))
    rng = _rng(t1, t2)
    area_pct = round(float(rng.random() * 22 + 6), 1)
    delta = round(float(rng.random() * 12 - 2), 2)
    facts = {
        "area_pct": area_pct,
        "class_deltas": {"built_up": delta, "water": round(float(rng.random() * 4 - 1), 2)},
        "polygons": [
            {"centroid_geo": [round(rng.random() * 0.01 + 25.0, 5), round(rng.random() * 0.01 + 85.0, 5)],
             "area_ha": round(float(rng.random() * 40 + 5), 1)}
            for _ in range(3)
        ],
    }
    mask = _write_mask("/tmp/satquery_change_mask.png", t1, t2)
    conf = round(float(np.clip(0.87 - (thr - 0.5) * 0.2, 0, 1)), 3)
    return {"mask": mask, "facts": facts, "confidence": conf}


def tool_change_vqa(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: M1 2-image head fine-tuned on CDVQA/QAG-360K.
    q = inputs.get("question", "")
    answer = "Stub change answer: new built-up development is concentrated along the northern road corridor."
    if any(w in q.lower() for w in ["increased", "decreased", "unchanged", "increas", "declin"]):
        answer = "Built-up area has increased by an estimated amount over the period."
    conf = round(float(np.clip(_rng(inputs["img_t1"], inputs["img_t2"], q).random() * 0.15 + 0.75, 0, 1)), 3)
    return {"answer": answer, "confidence": conf}


def tool_xmodal_caption(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: M6 dual-tower fusion (or M1 2-image mode) joint caption.
    optical, sar = inputs["optical"], inputs["sar"]
    caption = (
        "Stub joint caption: optical shows built-up and water; SAR backscatter is "
        "consistent, suggesting stable man-made structures and open water."
    )
    per_modality = {
        "optical": "built-up structures, water body, road network",
        "sar": "high backscatter over built-up, low over water",
    }
    conf = round(float(np.clip(_rng(optical, sar).random() * 0.2 + 0.72, 0, 1)), 3)
    return {"caption": caption, "per_modality": per_modality, "confidence": conf}


def tool_xmodal_vqa(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: M6 fusion VQA.
    q = inputs.get("question", "")
    answer = "Stub xmodal answer: combining optical and SAR, built-up regions are confirmed in the northeast."
    conf = round(float(np.clip(_rng(inputs["optical"], inputs["sar"], q).random() * 0.2 + 0.70, 0, 1)), 3)
    return {"answer": answer, "confidence": conf}


def tool_xmodal_mask(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: dual-input UNet++ per-pixel built_up/water masks.
    optical, sar = inputs["optical"], inputs["sar"]
    bu = _write_mask("/tmp/satquery_builtup.png", optical, sar)
    wa = _write_mask("/tmp/satquery_water.png", optical, sar + "w")
    per_class_iou = {"built_up": round(float(_rng(optical, sar).random() * 0.15 + 0.78), 3),
                     "water": round(float(_rng(optical, sar, "w").random() * 0.15 + 0.74), 3)}
    conf = round(float(np.mean(list(per_class_iou.values()))), 3)
    return {"masks": {"built_up": bu, "water": wa}, "per_class_iou": per_class_iou, "confidence": conf}


def tool_integrate(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # TOREPLACE: LLM integrator. MUST render the final answer ONLY from the
    # provided tool outputs (never invent numbers). Currently a templated narrator
    # that pulls the most confident tool's answer and lists evidence.
    outs: list[Dict[str, Any]] = inputs.get("tool_outputs", [])
    images = inputs.get("images", [])
    parts = [o for o in outs if o.get("answer")]
    best = max(parts, key=lambda o: o.get("confidence", 0), default=None)
    answer = best["answer"] if best else (
        "Analysis complete. Primary findings are summarized from the tool outputs "
        "with confidence and visual evidence below."
    )
    # Attach citations for every tool whose output supported the answer.
    citations = [
        {"claim": (o.get("caption") or o.get("answer") or o.get("mask") or "tool result")[:80],
         "tool": o.get("tool", "?")}
        for o in outs
    ]
    n = len(outs) or 1
    conf = round(float(np.mean([o.get("confidence", 0.5) for o in outs] or [0.6])), 3)
    return {"answer": answer, "citations": citations, "confidence": conf}


# ---------------------------------------------------------------------------
# Tool name -> callable dispatch. Executor uses this only.
# ---------------------------------------------------------------------------
TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "vqa": tool_vqa,
    "caption": tool_caption,
    "ground": tool_ground,
    "change_map": tool_change_map,
    "change_vqa": tool_change_vqa,
    "xmodal_caption": tool_xmodal_caption,
    "xmodal_vqa": tool_xmodal_vqa,
    "xmodal_mask": tool_xmodal_mask,
    "integrate": tool_integrate,
}
