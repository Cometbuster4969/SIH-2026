# Executor: runs a validated Plan's DAG over the registered tools.
#
# Guarantees (architecture.md §8 / design.md §3):
#   * runs steps in dependency order (topological),
#   * per-step timeout + 1 retry,
#   * structured outputs only (each tool returns the ToolOutput contract),
#   * partial failure => degrade: drop the step, continue, flag in the trace.
# It never calls a model directly; it dispatches through tools.TOOLS only.

from __future__ import annotations

import time
from copy import deepcopy
from typing import Dict, List

from ..tools import TOOLS
from .schemas import Plan, ToolOutput, TraceRow

STEP_TIMEOUT_S = 30
MAX_RETRIES = 1


def _topo_order(plan: Plan) -> List[int]:
    """Return step ids in a valid execution order."""
    order: List[int] = []
    done: set = set()
    pending = list(plan.steps)
    while pending:
        progressed = False
        for s in list(pending):
            if all(d in done for d in s.depends_on):
                order.append(s.id)
                done.add(s.id)
                pending.remove(s)
                progressed = True
        if not progressed:  # shouldn't happen (guardrail blocks cycles)
            order.extend(s.id for s in pending)
            break
    return order


def execute(plan: Plan, inventory: dict, inputs_by_id: Dict[int, dict]) -> Tuple[List[TraceRow], dict]:
    """Run the plan. Returns (trace_rows, last_tool_outputs_by_id).

    Tool inputs are resolved from `inputs_by_id` (mapping step-id -> image paths
    / params that the caller already prepared from the inventory). For tools that
    need a previous step's output (e.g. change_vqa needs change_map facts), the
    outputs of dependencies are merged in automatically.
    """
    rows: List[TraceRow] = []
    outputs: Dict[int, ToolOutput] = {}

    for sid in _topo_order(plan):
        step = next(s for s in plan.steps if s.id == sid)
        tool_name = step.tool
        fn = TOOLS.get(tool_name)
        if fn is None:
            rows.append(TraceRow(seq=sid, tool=tool_name, version="?", status="missing",
                                 latency_ms=0))
            continue

        # Build inputs: supplied inputs + params + outputs of dependencies.
        tool_inputs = dict(inputs_by_id.get(sid, {}))
        tool_inputs.update(step.params)
        for dep in step.depends_on:
            if dep in outputs:
                tool_inputs.setdefault("tool_outputs", [])
                tool_inputs["tool_outputs"].append(outputs[dep].model_dump())

        # Per-step timeout + retry.
        t0 = time.time()
        status = "ok"
        err: str = ""
        run_inputs = deepcopy(tool_inputs)
        out_dict: dict = {}
        for attempt in range(1 + MAX_RETRIES):
            try:
                st = time.time()
                out_dict = fn(run_inputs)
                status = "ok"
                err = ""
                break
            except Exception as e:  # noqa: BLE001 - degrade, never crash the agent
                status = "error"
                err = str(e)
                if attempt < MAX_RETRIES:
                    continue
        latency_ms = int((time.time() - t0) * 1000)

        out = ToolOutput(
            tool=tool_name,
            version=_version_for(tool_name),
            status=status,
            confidence=float(out_dict.get("confidence", 0.0)) if status == "ok" else 0.0,
            latency_ms=latency_ms,
            answer=out_dict.get("answer"),
            mask=out_dict.get("mask"),
            masks=out_dict.get("masks", {}),
            facts=out_dict.get("facts", {}),
            boxes=out_dict.get("boxes", []),
            citations=out_dict.get("citations", []),
            images=inputs_by_id.get(sid, {}).get("images", []),
        )
        outputs[sid] = out

        rows.append(TraceRow(
            seq=sid, tool=tool_name, version=out.version, params=step.params,
            inputs=tool_inputs, output_summary=out.model_dump(),
            confidence=out.confidence, latency_ms=latency_ms, status=status,
        ))

    # Integrator step is just the `integrate` tool; produce final answer.
    return rows, outputs


def _version_for(tool_name: str) -> str:
    from .registry import registry
    return registry.get(tool_name, {}).get("version", "stub-v1")
