# Planner: turns (query, input inventory) into a structured Plan.
#
# DESIGN GUARANTEE (architecture.md §8): the planner is NON-essential for
# correctness in the demo. If the LLM plan is missing/invalid, the Guardrail's
# rule-based fallback router produces a valid plan. So the skeleton ships with a
# robust DETERMINISTIC planner (RULES) that always yields a schema-valid plan,
# plus a pluggable LLM planner (LLMPlanner) that the team can enable once a model
# is wired up. The executor never cares which one produced the plan.

from __future__ import annotations

import re
import time
from typing import List, Optional, Tuple

from .registry import CANONICAL_PLANS, TASKS
from .schemas import Plan, Step

# ---------------------------------------------------------------------------
# Intent inference from the query text (deterministic keyword rules).
# ---------------------------------------------------------------------------
# Precedence matters (checked top to bottom): trend > classify > highlight >
# describe > ask. So "has built-up increased?" -> trend, "identify built-up" ->
# classify, "highlight the water body" -> highlight, "what changed...where?" ->
# ask (which routes change queries to change_vqa). Bare "where" is intentionally
# NOT a highlight trigger so the canonical change query isn't mis-routed.
_INTENT_RULES: List[Tuple[str, List[str]]] = [
    ("trend", ["increased", "decreased", "unchanged", "grow", "shrink", "more", "less", "trend", "change direction"]),
    ("classify", ["built-up", "built up", "builtup", "water-covered", "water covered",
                  "urban", "segmentation", "categories", "land-cover type", "class"]),
    ("highlight", ["highlight", "locate", "which area", "which region", "show me",
                   "point to", "identify", "mark", "find"]),
    ("describe", ["describe", "caption", "what is", "what are", "what do you see",
                  "tell me", "overview", "situation", "scenery"]),
    ("ask", ["?", "how many", "is there", "are there", "what objects", "count",
             "question", "object", "changed between"]),
]


def infer_intent(query: str) -> str:
    """Returns one of: trend | highlight | classify | describe | ask."""
    q = query.lower()
    for intent, words in _INTENT_RULES:
        for w in words:
            if w in q:
                return intent
    # Default for bare questions is "ask"; for statements "describe".
    return "ask" if q.strip().endswith("?") else "describe"


def infer_task(intent: str, scope: str) -> Optional[str]:
    """Pick a task label from intent + scope, using the canonical table."""
    from .registry import SCOPE_ALLOWED_TASKS
    if scope not in SCOPE_ALLOWED_TASKS:
        return "COMPAT_REPORT"
    allowed = SCOPE_ALLOWED_TASKS[scope]
    mapping = {
        "bi_temporal": {"describe": "CHANGE_DESC", "ask": "CHANGE_VQA", "highlight": "CHANGE_MAP",
                        "classify": "CHANGE_MAP", "trend": "CHANGE_VQA"},
        "cross_modal": {"describe": "XMODAL_CAPTION", "ask": "XMODAL_VQA", "highlight": "XMODAL_VQA",
                        "classify": "XMODAL_MASK", "trend": "XMODAL_VQA"},
        "single_optical": {"describe": "CAPTION", "ask": "VQA", "highlight": "GROUND",
                           "classify": "VQA", "trend": "VQA"},
        "single_sar": {"describe": "CAPTION", "ask": "VQA", "highlight": "GROUND",
                       "classify": "VQA", "trend": "VQA"},
    }
    task = mapping.get(scope, {}).get(intent)
    if task and task in allowed:
        return task
    # Fall back to a task that's at least allowed for this scope.
    for cand in allowed:
        if cand in TASKS:
            return cand
    return "COMPAT_REPORT"


def _steps_for(task: str, scope: str, query: str, intent: str) -> List[Step]:
    """Build the ordered step list for a given task (rule-based)."""
    base_seq = {
        "CAPTION": ["caption"],
        "VQA": ["vqa"],
        "GROUND": ["ground"],
        "CHANGE_DESC": ["change_map", "change_vqa"],
        "CHANGE_VQA": ["change_map", "change_vqa"],
        "CHANGE_MAP": ["change_map"],
        "XMODAL_CAPTION": ["xmodal_caption", "xmodal_mask"],
        "XMODAL_VQA": ["xmodal_vqa"],
        "XMODAL_MASK": ["xmodal_mask"],
        "COMPAT_REPORT": [],
    }
    tools = list(base_seq.get(task, []))
    # Multi-step compound queries: append grounding when query asks to highlight.
    if intent == "highlight" and task not in ("GROUND",) and "ground" not in tools and \
            scope in ("single_optical", "single_sar"):
        tools.append("ground")
    steps: List[Step] = []
    for i, t in enumerate(tools):
        params: dict = {}
        if t == "ground":
            params["phrase"] = _extract_phrase(query)
        # Only inject params that are in the tool's whitelist (guardrail enforces
        # this). change_map accepts thr; xmodal_mask currently has an empty
        # whitelist so we must NOT inject anything for it.
        if t == "change_map":
            params["thr"] = 0.5
        steps.append(Step(id=i + 1, tool=t, params=params,
                          depends_on=[j for j in range(1, i + 1)]))
    # Always terminate with integrate.
    steps.append(Step(id=len(steps) + 1, tool="integrate",
                      depends_on=[len(steps)]))
    return steps


def _extract_phrase(query: str) -> str:
    # Crude phrase extraction for the grounding stub. The rule router passes the
    # query down; the grounding tool interprets it. In the real system the LLM
    # planner supplies a cleaner phrase.
    q = query.strip().strip('"').rstrip("?")
    return q.split("highlight", 1)[-1].split("where", 1)[-1].strip() if "highlight" in q.lower() else "water body"


class RulePlanner:
    """Deterministic planner — always produces a schema-valid plan."""

    def plan(self, query: str, inventory: dict) -> Plan:
        t0 = time.time()
        scope = inventory.get("pair", {}).get("type", "single_optical")
        intent = infer_intent(query)
        task = infer_task(intent, scope)
        steps = _steps_for(task, scope, query, intent)
        # Look for a matching canonical entry to mark fallback-ish provenance.
        return Plan(
            task=task,
            steps=steps,
            planner={"model": "rules-v1", "fallback_used": False,
                     "latency_ms": int((time.time() - t0) * 1000)},
        )


class LLMPlanner:
    """Pluggable LLM planner. Wired up later (M2). Returns a Plan or None.

    >>> TEAM: set `enabled=True` and implement `_call_llm` once M2 (or the RS-VLM)
    >>> is served. On any exception return None -> guardrail routes to rules.
    """

    enabled = False  # flip to True when an LLM plan generator is available

    def __init__(self, model_name: str = "qwen2.5-7b-4bit"):
        self.model_name = model_name

    def plan(self, query: str, inventory: dict, registry_ctx: dict) -> Optional[Plan]:
        if not self.enabled:
            return None
        t0 = time.time()
        try:
            payload = self._call_llm(query, inventory, registry_ctx)
            plan = Plan.model_validate(payload)
            plan.planner["model"] = self.model_name
            plan.planner["fallback_used"] = False
            plan.planner["latency_ms"] = int((time.time() - t0) * 1000)
            return plan
        except Exception:
            return None  # guardrail will fall back to rules

    def _call_llm(self, query: str, inventory: dict, ctx: dict) -> dict:
        raise NotImplementedError("Wire M2 here.")


def route_plan(query: str, inventory: dict) -> Plan:
    """Public entry used by the orchestrator: try LLM, then rules."""
    llm = LLMPlanner()
    plan = llm.plan(query, inventory, registry_ctx={})
    if plan is None:
        plan = RulePlanner().plan(query, inventory)
    return plan
