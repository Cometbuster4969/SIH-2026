# Rule-based Fallback Router.
#
# If the LLM plan fails validation (or there is no LLM), the orchestrator calls
# this to deterministically produce a guaranteed-valid plan. It is keyed on the
# canonical table (registry.CANONICAL_PLANS) by (scope, intent). Because the rule
# planner (planner.RulePlanner) already produces from this same table, the router
# here is mainly a safety net and the place where `fallback_used=true` is stamped.

from __future__ import annotations

import time
from typing import Dict, List

from .planner import RulePlanner, infer_intent, infer_task, _steps_for
from .schemas import Plan


def fallback_plan(query: str, inventory: dict) -> Plan:
    """Return a guaranteed schema-valid canonical plan, stamped fallback_used."""
    plan = RulePlanner().plan(query, inventory)
    plan.planner["fallback_used"] = True
    plan.planner["model"] = "rulerouter-v1"
    return plan
