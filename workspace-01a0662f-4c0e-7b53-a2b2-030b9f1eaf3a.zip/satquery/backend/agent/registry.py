# Tool registry definition.
#
# This is the SINGLE SOURCE OF TRUTH for what tools exist. The agent only ever
# plans over this registry; the guardrail validates plans against it; and
# `GET /api/v1/tools` serializes it (proves the "predefined registry" requirement).
#
# Every tool entry has:
#   name       - stable tool key used by the planner
#   version    - model/implementation version string (recorded in every trace)
#   model      - which component implements it (M1..M7 / T5). SEE architecture.md.
#   kind       - task family the tool serves
#   inputs     - JSON-schema-ish dict describing allowed inputs + defaults
#   outputs    - JSON-schema-ish dict describing the structured output contract
#   whitelist  - list of param keys the planner is allowed to set (PS A2.4)
#   notes      - what the stub returns / what the team must replace
#
# >>> TEAM: leave `contract` fields alone. Replace only the stub internals in
# >>> backend/tools/*.py. Keeping the contract stable keeps traces/eval stable.

registry = {
    "vqa": {
        "version": "m1-v1.0-stub",
        "model": "M1",
        "kind": "VQA",
        "inputs": {"image": "path", "question": "str"},
        "outputs": {"answer": "str", "answer_type": "str", "confidence": "float"},
        "whitelist": ["temp"],
        "notes": "REPLACE: call Qwen2-VL (or InternVL) on `image` with `question`.",
    },
    "caption": {
        "version": "m1-v1.0-stub",
        "model": "M1",
        "kind": "CAPTION",
        "inputs": {"image": "path"},
        "outputs": {"caption": "str", "facts": {"landcover": "str", "objects": ["str"]},
                     "confidence": "float"},
        "whitelist": [],
        "notes": "REPLACE: call RS-VLM caption head.",
    },
    "ground": {
        "version": "m3-v1.0-stub",
        "model": "M3",
        "kind": "GROUND",
        "inputs": {"image": "path", "phrase": "str"},
        "outputs": {"boxes": [{"xywh": [4], "score": "float", "label": "str"}],
                     "confidence": "float"},
        "whitelist": ["thr"],
        "notes": "REPLACE: Grounding-DINO-T fine-tuned box detector.",
    },
    "change_map": {
        "version": "m4-v1.0-stub",
        "model": "M4",
        "kind": "CHANGE_MAP",
        "inputs": {"img_t1": "path", "img_t2": "path", "thr": "float"},
        "outputs": {"mask": "path", "facts": {"area_pct": "float", "class_deltas": "dict",
                     "polygons": [{"centroid_geo": [2], "area_ha": "float"}]},
                     "confidence": "float"},
        "whitelist": ["thr", "tile"],
        "notes": "REPLACE: BiT/ChangeFormer change-detection backbone.",
    },
    "change_vqa": {
        "version": "m5-v1.0-stub",
        "model": "M5",
        "kind": "CHANGE_VQA",
        "inputs": {"img_t1": "path", "img_t2": "path", "question": "str", "change_facts": "dict"},
        "outputs": {"answer": "str", "confidence": "float"},
        "whitelist": ["temp"],
        "notes": "REPLACE: M1 2-image head fine-tuned on CDVQA/QAG-360K.",
    },
    "xmodal_caption": {
        "version": "m6-v1.0-stub",
        "model": "M6",
        "kind": "XMODAL_CAPTION",
        "inputs": {"optical": "path", "sar": "path"},
        "outputs": {"caption": "str", "per_modality": "dict", "confidence": "float"},
        "whitelist": [],
        "notes": "REPLACE: M6 dual-tower fusion (or M1 2-image mode).",
    },
    "xmodal_vqa": {
        "version": "m6-v1.0-stub",
        "model": "M6",
        "kind": "XMODAL_VQA",
        "inputs": {"optical": "path", "sar": "path", "question": "str"},
        "outputs": {"answer": "str", "confidence": "float"},
        "whitelist": ["temp"],
        "notes": "REPLACE: M6 fusion (or M1 2-image mode).",
    },
    "xmodal_mask": {
        "version": "m7-v1.0-stub",
        "model": "M7",
        "kind": "XMODAL_MASK",
        "inputs": {"optical": "path", "sar": "path"},
        "outputs": {"masks": {"built_up": "path", "water": "path"},
                     "per_class_iou": "dict", "confidence": "float"},
        "whitelist": [],
        "notes": "REPLACE: dual-input UNet++ (+ see patch-classifier reframe in proposedidea.md).",
    },
    "integrate": {
        "version": "m2-v1.0-stub",
        "model": "M2",
        "kind": "INTEGRATE",
        "inputs": {"tool_outputs": "json", "images": ["path"]},
        "outputs": {"answer": "str", "citations": [{"claim": "str", "tool": "str"}],
                     "confidence": "float"},
        "whitelist": [],
        "notes": "REPLACE: LLM integrator; MUST keep 'answer ONLY from tool outputs' rule.",
    },
}

# Task taxonomy used by planner/guardrail (mirrors architecture.md §8).
TASKS = [
    "CAPTION", "VQA", "GROUND",
    "CHANGE_DESC", "CHANGE_VQA", "CHANGE_MAP",
    "XMODAL_CAPTION", "XMODAL_VQA", "XMODAL_MASK",
    "COMPAT_REPORT", "MULTI_STEP",
]

# Which tasks each input SCOPE is allowed to run (guardrail enforces this). This is
# the PS "input compatibility" hard constraint.
SCOPE_ALLOWED_TASKS = {
    "single_optical":  ["CAPTION", "VQA", "GROUND"],
    "single_sar":      ["CAPTION", "VQA", "GROUND"],
    "bi_temporal":     ["CHANGE_DESC", "CHANGE_VQA", "CHANGE_MAP", "MULTI_STEP", "VQA", "CAPTION"],
    "cross_modal":     ["XMODAL_CAPTION", "XMODAL_VQA", "XMODAL_MASK", "MULTI_STEP", "VQA", "CAPTION"],
}

# Canonical fallback plans (rule router), keyed by (scope, intent). Mirrors
# architecture.md §6. All plans implicitly end with `integrate`.
CANONICAL_PLANS = {
    ("single_optical", "describe"):      ["caption"],
    ("single_optical", "ask"):           ["vqa"],
    ("single_optical", "highlight"):     ["ground"],
    ("single_sar",     "describe"):      ["caption"],
    ("single_sar",     "ask"):           ["vqa"],
    ("single_sar",     "highlight"):     ["ground"],
    ("bi_temporal",    "describe"):      ["change_map", "change_vqa"],
    ("bi_temporal",    "ask"):           ["change_map", "change_vqa"],
    ("bi_temporal",    "highlight"):     ["change_map", "ground"],
    ("bi_temporal",    "classify"):      ["change_map"],
    ("bi_temporal",    "trend"):         ["change_map", "change_vqa"],
    ("cross_modal",    "describe"):      ["xmodal_caption", "xmodal_mask"],
    ("cross_modal",    "ask"):           ["xmodal_vqa"],
    ("cross_modal",    "highlight"):     ["xmodal_vqa", "ground"],
    ("cross_modal",    "classify"):      ["xmodal_mask"],
}
