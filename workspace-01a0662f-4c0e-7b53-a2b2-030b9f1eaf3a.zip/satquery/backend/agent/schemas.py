# Pydantic schemas for the agent's internal + API-facing objects.
# These are the audit contract: every plan, step, tool output and trace row is
# serializable JSON so the evaluator (and the PDF report) can consume them.

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Step(BaseModel):
    id: int
    tool: str
    params: Dict[str, Any] = Field(default_factory=dict)
    depends_on: List[int] = Field(default_factory=list)


class Plan(BaseModel):
    task: str
    steps: List[Step] = Field(default_factory=list)
    planner: Dict[str, Any] = Field(default_factory=dict)  # model, fallback_used, latency_ms


class ToolOutput(BaseModel):
    tool: str
    version: str
    status: str = "ok"
    answer: Optional[str] = None
    mask: Optional[str] = None                      # single change mask path
    masks: Dict[str, str] = Field(default_factory=dict)  # label -> path
    facts: Dict[str, Any] = Field(default_factory=dict)
    boxes: List[Dict[str, Any]] = Field(default_factory=list)
    citations: List[Dict[str, Any]] = Field(default_factory=list)
    confidence: float = 0.0
    latency_ms: int = 0
    evidence: List[str] = Field(default_factory=list)
    images: List[str] = Field(default_factory=list)


class TraceRow(BaseModel):
    seq: int
    tool: str
    version: str
    params: Dict[str, Any] = Field(default_factory=dict)
    inputs: Dict[str, Any] = Field(default_factory=dict)
    output_summary: Dict[str, Any] = Field(default_factory=dict)
    confidence: float = 0.0
    latency_ms: int = 0
    status: str = "ok"


class RequestResult(BaseModel):
    request_id: str
    query: str
    task: Optional[str] = None
    final_answer: Optional[str] = None
    confidence: Optional[float] = None
    total_ms: int = 0
    fallback_used: bool = False
    status: str = "PENDING"
    trace: List[TraceRow] = Field(default_factory=list)
    report_url: Optional[str] = None
    overlays: List[Dict[str, Any]] = Field(default_factory=list)
