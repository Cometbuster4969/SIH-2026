# Integrator: combines tool outputs into a final answer with citations + confidence.
#
# In the real system this is an LLM call (M2 / the RS-VLM) with a strict prompt:
#   "Answer ONLY from the provided tool outputs + images; cite which tool produced
#    each claim; state confidence; never invent numbers."
# In the skeleton it's a deterministic narrators/converter (tool_integrate) that
# respects the same rule: it pulls the answer text and citations from tool outputs
# and never fabricates numbers — numeric facts are surfaced verbatim from tools.

from __future__ import annotations

from typing import Dict, List

from ..tools import tool_integrate
from .schemas import ToolOutput


def integrate(outputs: List[ToolOutput], images: List[str]) -> Dict[str, object]:
    """Return {answer, citations, confidence} derived strictly from tool outputs."""
    raw = tool_integrate({
        "tool_outputs": [o.model_dump() for o in outputs],
        "images": images,
    })
    return {
        "answer": raw.get("answer", ""),
        "citations": raw.get("citations", []),
        "confidence": float(raw.get("confidence", 0.0)),
    }


# ---------------------------------------------------------------------------
# Confidence aggregation (T5 / design.md §7).
#   final = weighted geometric mean over per-tool confidences,
#   badges: High >= 0.75, Med 0.50-0.75, Low < 0.50,
#   disagreement rule (optical vs SAR on a shared claim) => flag.
# ---------------------------------------------------------------------------

# Relative weight by tool (task criticality). Tune post-selection.
_TOOL_WEIGHTS = {
    "vqa": 1.0, "caption": 0.8, "ground": 1.0,
    "change_map": 1.2, "change_vqa": 1.0,
    "xmodal_caption": 0.9, "xmodal_vqa": 1.0, "xmodal_mask": 1.2,
}


def aggregate_confidence(rows: List) -> Dict[str, object]:
    """rows: list of TraceRow with `.tool` and `.confidence`."""
    vals = [r.confidence for r in rows if r.confidence > 0]
    if not vals:
        return {"confidence": 0.0, "badge": "Low", "disagreement": []}

    weights = [_TOOL_WEIGHTS.get(r.tool, 0.9) for r in rows if r.confidence > 0]
    geo_mean = _geo_mean(vals, weights)
    conf = round(float(geo_mean), 3)

    # Disagreement rule is really per-claim in the real system; here we emit a
    # placeholder when a cross-modal run has strongly divergent per-modality conf.
    disagreement = []
    if any(r.tool.startswith("xmodal_") for r in rows):
        # Placeholder: real disagreement detection comes from per-class outputs.
        disagreement = ["optical vs SAR per-class confidence to be checked post-selection"]

    return {"confidence": conf, "badge": _badge(conf), "disagreement": disagreement}


def _geo_mean(vals, weights):
    import math
    wsum = sum(weights)
    # vectorized-ish geometric mean (avoid overflow)
    log_acc = sum(w * math.log(max(v, 1e-6)) for w, v in zip(weights, vals))
    return math.exp(log_acc / max(wsum, 1e-6))


def _badge(conf: float) -> str:
    if conf >= 0.75:
        return "High"
    if conf >= 0.50:
        return "Med"
    return "Low"
