# Deterministic Guardrail Validator.
#
# It enforces the hard constraints from the PS, in order, and NEVER raises:
#   * on failure it returns (ok=False, reason=...) and the orchestrator routes to
#     the rule-based fallback router. The user never sees a crash.
# Rules enforced (architecture.md §8 / design.md §9):
#   1. input-scope => allowed task set (hard).
#   2. plan passes JSON schema (via pydantic) and every tool is in the registry.
#   3. step params are a subset of the per-tool whitelist (PS A2.4).
#   4. no dependency cycles; depends_on resolvable; steps reference existing ids.

from __future__ import annotations

from typing import Dict, List, Tuple

from .registry import SCOPE_ALLOWED_TASKS, registry
from .schemas import Plan


def _scope_of(inventory: dict) -> str:
    return inventory.get("pair", {}).get("type", "single_optical")


def validate(plan: Plan, inventory: dict) -> Tuple[bool, str]:
    scope = _scope_of(inventory)

    # 1. Scope / task compatibility (hard).
    allowed = SCOPE_ALLOWED_TASKS.get(scope, [])
    if plan.task not in allowed:
        return False, f"task={plan.task!r} not allowed for scope={scope!r}"

    # 2. Tools exist in registry.
    step_ids: set = set()
    for s in plan.steps:
        if s.tool not in registry:
            return False, f"unknown tool={s.tool!r} not in registry"
        step_ids.add(s.id)

    # 3. Parameter whitelist per tool.
    for s in plan.steps:
        allowed_params = set(registry[s.tool].get("whitelist", []))
        bad = set(s.params.keys()) - allowed_params
        if bad:
            return False, f"tool={s.tool!r} has disallowed params {sorted(bad)}"

    # 4a. depends_on resolvable.
    for s in plan.steps:
        for d in s.depends_on:
            if d not in step_ids:
                return False, f"step {s.id} depends on unknown id {d}"

    # 4b. No cycles (topological check).
    if _has_cycle(plan):
        return False, "dependency cycle in plan"

    return True, "ok"


def _has_cycle(plan: Plan) -> bool:
    by_id = {s.id: s for s in plan.steps}
    visiting: set = set()
    visited: set = set()

    def visit(nid: int) -> bool:
        s = by_id.get(nid)
        if s is None:
            return False
        if nid in visiting:
            return True
        if nid in visited:
            return False
        visiting.add(nid)
        for d in s.depends_on:
            if visit(d):
                return True
        visiting.remove(nid)
        visited.add(nid)
        return False

    return any(visit(s.id) for s in plan.steps)
