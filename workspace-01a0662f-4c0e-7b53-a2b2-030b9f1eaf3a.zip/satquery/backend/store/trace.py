# Durable trace store (SQLite). Mirrors architecture.md §11.
# Every DONE request => a complete, auditable trace (PS A2.6).

from __future__ import annotations

import json
import sqlite3
import threading
from typing import Dict, List, Optional

_SCHEMA = """
CREATE TABLE IF NOT EXISTS requests(
    id TEXT PRIMARY KEY, created_at TEXT, query TEXT,
    inventory_json TEXT, task TEXT, plan_json TEXT,
    planner_model TEXT, fallback_used INTEGER,
    final_answer TEXT, confidence REAL, total_ms INTEGER, report_path TEXT
);
CREATE TABLE IF NOT EXISTS request_steps(
    id TEXT PRIMARY KEY, request_id TEXT, seq INTEGER, tool TEXT, version TEXT,
    params_json TEXT, inputs_json TEXT, output_summary_json TEXT,
    confidence REAL, latency_ms INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS artifacts(
    id TEXT PRIMARY KEY, request_id TEXT, kind TEXT, path TEXT, meta_json TEXT
);
"""


class TraceStore:
    def __init__(self, db_path: str = "/data/traces.db"):
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def save_request(self, req: dict) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    req.get("id"), req.get("created_at"), req.get("query"),
                    json.dumps(req.get("inventory", {})), req.get("task"),
                    json.dumps(req.get("plan", {})), req.get("planner_model"),
                    int(req.get("fallback_used", False)),
                    req.get("final_answer"), req.get("confidence"),
                    req.get("total_ms"), req.get("report_path"),
                ),
            )
            for i, step in enumerate(req.get("steps", [])):
                self._conn.execute(
                    "INSERT OR REPLACE INTO request_steps VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        f"{req.get('id')}:{i}", req.get("id"), step.get("seq"),
                        step.get("tool"), step.get("version"),
                        json.dumps(step.get("params", {})),
                        json.dumps(step.get("inputs", {})),
                        json.dumps(step.get("output_summary", {})),
                        step.get("confidence", 0), step.get("latency_ms", 0),
                        step.get("status", "ok"),
                    ),
                )
            for a in req.get("artifacts", []):
                self._conn.execute(
                    "INSERT OR REPLACE INTO artifacts VALUES (?,?,?,?,?)",
                    (a.get("id"), req.get("id"), a.get("kind"),
                     a.get("path"), json.dumps(a.get("meta", {}))),
                )
            self._conn.commit()

    def get_request(self, request_id: str) -> Optional[dict]:
        with self._lock:
            cur = self._conn.execute("SELECT * FROM requests WHERE id=?", (request_id,))
            row = cur.fetchone()
            if not row:
                return None
            cols = [d[0] for d in cur.description]
            d = dict(zip(cols, row))
            scur = self._conn.execute(
                "SELECT * FROM request_steps WHERE request_id=? ORDER BY seq",
                (request_id,),
            )
            scol = [d[0] for d in scur.description]
            steps = [dict(zip(scol, r)) for r in scur.fetchall()]
            return _deserialize(d, steps)

    def list_requests(self) -> List[dict]:
        with self._lock:
            cur = self._conn.execute("SELECT id, task, confidence, total_ms, fallback_used, created_at FROM requests ORDER BY created_at DESC")
            return [dict(zip([d[0] for d in cur.description], r)) for r in cur.fetchall()]


def _deserialize(d: dict, steps_rows) -> dict:
    def load(x):
        try:
            return json.loads(x)
        except Exception:
            return {}
    return {
        "id": d["id"], "query": d["query"],
        "inventory": load(d["inventory_json"]), "task": d["task"],
        "plan": load(d["plan_json"]), "planner_model": d["planner_model"],
        "fallback_used": bool(d["fallback_used"]), "final_answer": d["final_answer"],
        "confidence": d["confidence"], "total_ms": d["total_ms"],
        "report_path": d["report_path"],
        "steps": [
            {
                "seq": r["seq"], "tool": r["tool"], "version": r["version"],
                "params": load(r["params_json"]), "inputs": load(r["inputs_json"]),
                "output_summary": load(r["output_summary_json"]),
                "confidence": r["confidence"], "latency_ms": r["latency_ms"],
                "status": r["status"],
            }
            for r in steps_rows
        ],
    }
