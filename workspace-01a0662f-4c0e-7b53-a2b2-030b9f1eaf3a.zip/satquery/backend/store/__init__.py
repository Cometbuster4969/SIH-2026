# SQLite trace store.
