# Orchestrator: end-to-end request lifecycle (design.md §3 state machine).
#
#   INGESTED -> PLANNING -> RUNNING(step i/n) -> INTEGRATING -> DONE
#              |                |  (plan invalid) -> RULE_PLAN -> RUNNING
#              any -> REJECTED (compatibility) | FAILED
#
# This ties together: planner -> guardrail -> (fallback) -> executor ->
# integrator -> confidence -> trace store. It is intentionally deterministic and
# never raises; every failure becomes a structured reject card or a degraded
# answer with a flag.

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional

from .agent.executor import execute
from .agent.guardrail import validate
from .agent.integrator import aggregate_confidence, integrate
from .agent.planner import route_plan
from .agent.rulerouter import fallback_plan
from .agent.schemas import Plan, TraceRow
from .store.trace import TraceStore

# Callback for streaming events to the UI (planner/WS). Optional.
EventHook = Callable[[str, dict], None]


class Orchestrator:
    def __init__(self, store: TraceStore, progress: Optional[EventHook] = None):
        self.store = store
        self._progress = progress or (lambda _ev, _d: None)

    def _emit(self, ev: str, payload: dict):
        self._progress(ev, payload)

    def run(self, request_id: str, query: str, inventory: dict) -> dict:
        """Full lifecycle for one query against a given inventory. Returns result dict."""
        t0 = time.time()
        self._emit("planning", {"request_id": request_id})

        # ---- 1. Plan (LLM preferred, rules guaranteed) ----
        plan: Plan = route_plan(query, inventory)
        ok, reason = validate(plan, inventory)
        if not ok:
            self._emit("plan_invalid", {"request_id": request_id, "reason": reason})
            plan = fallback_plan(query, inventory)
            plan.task = _compatible_task(plan, inventory)
            ok, reason = validate(plan, inventory)
            if not ok:
                return self._reject(request_id, query, inventory, reason, t0)

        # ---- 2. Execute ----
        self._emit("running", {"request_id": request_id, "task": plan.task,
                               "plan": [s.tool for s in plan.steps]})
        inputs_by_id = _inputs_for_plan(plan, inventory)
        rows, outputs = execute(plan, inventory, inputs_by_id)

        # ---- 3. Integrate ----
        self._emit("integrating", {"request_id": request_id})
        tool_outputs = [o for o in outputs.values() if o.status == "ok"]
        final = integrate(tool_outputs, _image_paths(inventory))
        agg = aggregate_confidence(rows)

        # ---- 4. Build result + persist trace ----
        result = build_result(
            request_id=request_id, query=query, inventory=inventory, plan=plan,
            rows=rows, final_answer=final["answer"], confidence=agg["confidence"],
            total_ms=int((time.time() - t0) * 1000),
            badge=agg["badge"], disagreement=agg["disagreement"],
        )
        self.store.save_request({
            "id": request_id, "created_at": _now(), "query": query,
            "inventory": inventory, "task": plan.task, "plan": plan.model_dump(),
            "planner_model": plan.planner.get("model"),
            "fallback_used": plan.planner.get("fallback_used", False),
            "final_answer": final["answer"], "confidence": agg["confidence"],
            "total_ms": result["total_ms"], "report_path": None,
            "steps": [r.model_dump() for r in rows],
        })
        self._emit("done", {"request_id": request_id,
                            "answer": final["answer"], "confidence": agg["confidence"]})
        return result

    def _reject(self, request_id, query, inventory, reason, t0) -> dict:
        self.store.save_request({
            "id": request_id, "created_at": _now(), "query": query,
            "inventory": inventory, "task": "COMPAT_REPORT", "plan": {},
            "planner_model": None, "fallback_used": False,
            "final_answer": None, "confidence": 0.0,
            "total_ms": int((time.time() - t0) * 1000), "report_path": None,
            "steps": [],
        })
        return {
            "request_id": request_id, "query": query, "status": "REJECTED",
            "final_answer": None, "confidence": 0.0,
            "total_ms": int((time.time() - t0) * 1000), "error": reason,
            "trace": [],
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def build_result(request_id, query, inventory, plan, rows, final_answer,
                 confidence, total_ms, badge, disagreement) -> dict:
    return {
        "request_id": request_id, "query": query, "status": "DONE",
        "task": plan.task, "final_answer": final_answer,
        "confidence": confidence, "badge": badge,
        "disagreement": disagreement,
        "total_ms": total_ms,
        "fallback_used": plan.planner.get("fallback_used", False),
        "planner_model": plan.planner.get("model"),
        "plan": plan.model_dump(),
        "trace": [r.model_dump() for r in rows],
        "overlays": _overlays(rows, inventory),
    }


def _compatible_task(plan: Plan, inventory: dict) -> str:
    return plan.task if plan.task else "COMPAT_REPORT"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _inputs_for_plan(plan: Plan, inventory: dict) -> Dict[int, dict]:
    """Map each step id -> the image paths / context that tool needs."""
    files = inventory.get("files", [])
    paths = [f.get("path") for f in files if f.get("path")]
    result: Dict[int, dict] = {}
    for s in plan.steps:
        images = list(paths)
        result[s.id] = {"images": images}
        _inject_tool_specific(s.tool, result[s.id], files)
    return result


def _inject_tool_specific(tool: str, d: dict, files: list):
    opt = [f for f in files if f.get("modality") == "optical"]
    sar = [f for f in files if f.get("modality") == "sar"]
    if tool == "change_map":
        d["img_t1"] = opt[0]["path"] if len(opt) >= 2 else (files[0]["path"] if files else None)
        d["img_t2"] = opt[1]["path"] if len(opt) >= 2 else (files[-1]["path"] if files else None)
    elif tool == "change_vqa":
        d["img_t1"] = opt[0]["path"] if len(opt) >= 2 else (files[0]["path"] if files else None)
        d["img_t2"] = opt[1]["path"] if len(opt) >= 2 else (files[-1]["path"] if files else None)
    elif tool in ("xmodal_caption", "xmodal_vqa", "xmodal_mask"):
        d["optical"] = opt[0]["path"] if opt else (files[0]["path"] if files else None)
        d["sar"] = sar[0]["path"] if sar else (files[-1]["path"] if files else None)
    elif tool in ("vqa", "caption", "ground"):
        d["image"] = files[0]["path"] if files else None


def _image_paths(inventory: dict) -> List[str]:
    return [f.get("path") for f in inventory.get("files", []) if f.get("path")]


def _overlays(rows: List[TraceRow], inventory: dict) -> List[dict]:
    outs = [r.output_summary for r in rows]
    layers = []
    for o in outs:
        if o.get("mask"):
            layers.append({"kind": "mask.change", "path": o["mask"], "label": "change map"})
        for key, label in (("built_up", "built-up"), ("water", "water")):
            if o.get("masks", {}).get(key):
                layers.append({"kind": f"mask.{key}", "path": o["masks"][key], "label": label})
        if o.get("boxes"):
            layers.append({"kind": "bbox", "boxes": o["boxes"], "label": "grounding"})
    return layers
