# FastAPI application — REST + WebSocket surface for the agent.
#
# Endpoints (design.md §9):
#   POST /api/v1/ingest            multipart files -> {request_id, inventory}
#   GET  /api/v1/demo/load         ingest a curated demo scene set (no upload needed)
#   POST /api/v1/query             {request_id, query} -> run the agent
#   GET  /api/v1/requests/{id}     full result
#   GET  /api/v1/requests/{id}/trace.json   auditable trace (PS artifact)
#   GET  /api/v1/tools             registry dump (proves "predefined registry")
#   POST /api/v1/warmup            load all weights (demo-day use; no-op in skeleton)
#   GET  /health  /version
# WebSocket /ws/{request_id}       streamed progress events (optional)

from __future__ import annotations

import asyncio
import os
import tempfile
import uuid

from fastapi import FastAPI, File, HTTPException, UploadFile, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ..agent.registry import registry, TASKS
from ..ingestion.validate import build_inventory
from ..orchestrator import Orchestrator
from ..store.trace import TraceStore

app = FastAPI(title="SatQuery AI", version="0.1.0-skeleton")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

# ---- wiring (singletons) ----
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = os.environ.get("SATQUERY_DB", os.path.join(_REPO_ROOT, "data", "traces.db"))
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
store = TraceStore(DB_PATH)

# Per-request progress hooks fed to clients via WS (best-effort in skeleton).
_ws_clients: dict = {}


def _broadcast(ev: str, payload: dict):
    rid = payload.get("request_id")
    ws = _ws_clients.get(rid)
    if ws is not None:
        try:
            asyncio.create_task(_ws_send(ws, {"event": ev, **payload}))
        except Exception:
            pass


async def _ws_send(ws, data: dict):
    try:
        await ws.send_json(data)
    except Exception:
        pass


orchestrator = Orchestrator(store, progress=_broadcast)

# In-memory inventory map (request_id -> inventory). In prod this comes from the
# evaluation set + the user's upload; here it demos the contract.
_INVENTORIES: dict = {}


@app.on_event("startup")
async def _startup():
    # put demo file dir on the static mount so overlays/images are servable
    demo_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "demo", "data", "demo")
    if os.path.isdir(demo_dir):
        app.mount("/demo", StaticFiles(directory=demo_dir), name="demo")


@app.get("/", response_class=HTMLResponse)
def index():
    frontend = os.path.join(_REPO_ROOT, "frontend", "index.html")
    try:
        with open(frontend, "r", encoding="utf-8") as fh:
            return HTMLResponse(fh.read())
    except FileNotFoundError:
        return HTMLResponse("<h3>frontend/index.html not found</h3>")


@app.get("/cover")
def cover(p: str):
    """Serve an overlay/mask image by local path (demo overlay preview)."""
    if p and os.path.exists(p):
        return FileResponse(p)
    raise HTTPException(404, "not found")


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0-skeleton"}


@app.get("/version")
def version():
    return {"name": "SatQuery AI", "version": "0.1.0-skeleton", "gpu": False,
            "gdal": bool(os.environ.get("SATQUERY_RASTERIO", "")) or None}


@app.get("/api/v1/tools")
def tools():
    return {"registry": registry, "tasks": TASKS}


@app.post("/api/v1/ingest")
async def ingest(files: list[UploadFile] = File(...)):
    request_id = uuid.uuid4().hex[:12]
    saved = []
    for f in files:
        data = await f.read()
        suffix = os.path.splitext(f.filename)[1] or ".tif"
        tmp = os.path.join(tempfile.gettempdir(), f"{request_id}_{f.filename or 'img'}{suffix}")
        with open(tmp, "wb") as fh:
            fh.write(data)
        saved.append({"path": tmp, "name": f.filename})
    inventory = build_inventory(saved, request_id)
    if "_error" in inventory:
        raise HTTPException(400, inventory["_error"])
    _INVENTORIES[request_id] = inventory
    return {"request_id": request_id, "inventory": inventory}


@app.post("/api/v1/demo/load")
def demo_load():
    """Ingest a curated demo scene set so the demo works without choosing files."""
    request_id = uuid.uuid4().hex[:12]
    demo_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "demo", "data", "demo")
    # Pick the bi-temporal pair by default.
    files = [
        {"path": os.path.join(demo_dir, "t1_optical.tif"), "name": "t1_optical.tif", "date": "2018-05-12"},
        {"path": os.path.join(demo_dir, "t2_optical.tif"), "name": "t2_optical.tif", "date": "2021-03-04"},
    ]
    inventory = build_inventory(files, request_id)
    _INVENTORIES[request_id] = inventory
    return {"request_id": request_id, "inventory": inventory}


class QueryIn(BaseModel):
    request_id: str
    query: str


@app.post("/api/v1/query")
def query(body: QueryIn):
    inventory = _INVENTORIES.get(body.request_id)
    if inventory is None:
        raise HTTPException(404, "unknown request_id — call /ingest or /demo/load first")
    result = orchestrator.run(body.request_id, body.query, inventory)
    return result


@app.get("/api/v1/requests/{request_id}")
def get_request(request_id: str):
    return store.get_request(request_id) or {"error": "not found"}


@app.get("/api/v1/requests/{request_id}/trace.json")
def get_trace(request_id: str):
    rec = store.get_request(request_id)
    if not rec:
        raise HTTPException(404, "trace not found")
    return {"request_id": request_id, "task": rec.get("task"),
            "planner_model": rec.get("planner_model"),
            "fallback_used": rec.get("fallback_used"),
            "confidence": rec.get("confidence"),
            "total_ms": rec.get("total_ms"),
            "steps": rec.get("steps", [])}


@app.post("/api/v1/warmup")
def warmup():
    return {"status": "ok", "note": "No weights to load yet (skeleton). Phase 2 loads M1-M7."}


@app.websocket("/ws/{request_id}")
async def ws_endpoint(ws: WebSocket, request_id: str):
    await ws.accept()
    _ws_clients[request_id] = ws
    try:
        while True:
            msg = await ws.receive_text()
            if msg == "ping":
                await ws.send_text("pong")
    except Exception:
        pass
    finally:
        _ws_clients.pop(request_id, None)
