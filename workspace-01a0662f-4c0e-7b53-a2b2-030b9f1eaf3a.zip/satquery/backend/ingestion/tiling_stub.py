# Placeholder for a real tiling module (GDAL geotransforms).
#
# The skeleton's tile_plan() lives in validate.py as a count-only estimator. When
# rasterio is available, replace this with a real implementation that:
#   * splits a raster into 512x512 tiles with 64px overlap,
#   * writes per-tile geotransforms and a tile -> geo-bounds index,
#   * stitches spatial outputs (boxes/masks/heatmaps) back to the full-image frame.
# Provide the same function signature so nothing downstream changes.
