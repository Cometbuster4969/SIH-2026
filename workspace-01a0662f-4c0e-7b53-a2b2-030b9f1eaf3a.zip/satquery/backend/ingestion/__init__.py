# Ingestion & validation service (architecture.md §5).
