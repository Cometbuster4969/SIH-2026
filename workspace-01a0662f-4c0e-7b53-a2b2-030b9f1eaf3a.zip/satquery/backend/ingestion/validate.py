# Ingestion & validation service (architecture.md §5).
#
# Wraps GDAL/rasterio when present; otherwise degrades to a Pillow-based check so
# the skeleton runs with zero native deps. The outputs (Inventory JSON) are IDENTICAL
# either way, so the agent/executor don't care. The team should install rasterio and
# enable the GDAL-only checks (marked WITH_GDAL) before any real GeoTIFF evaluation.

from __future__ import annotations

import hashlib
import os
import re
from typing import Dict, List, Optional

from PIL import Image

# PNG/JPEG are ONLY accepted for prescribed benchmark dataset dirs (PS input scope).
BENCHMARK_ALLOWLIST_DIRS = ["VRSBench", "RSVQA", "CDVQA", "QAG-360K", "ChangeChat"]

ALLOWED_EXTS = {".tif", ".tiff", ".geotiff"}
BENCHMARK_EXTS = {".png", ".jpg", ".jpeg"}

try:
    import rasterio  # type: ignore  (optional; feature-flagged)
    HAS_RASTERIO = True
except Exception:  # noqa: BLE001
    rasterio = None
    HAS_RASTERIO = False


# ---------------------------------------------------------------------------
# Format + benchmark allow-list gate
# ---------------------------------------------------------------------------

def _in_benchmark_dir(path: str) -> bool:
    norm = path.replace("\\", "/")
    return any(d in norm for d in BENCHMARK_ALLOWLIST_DIRS)


def validate_format(path: str) -> Dict[str, object]:
    ext = os.path.splitext(path)[1].lower()
    if ext in ALLOWED_EXTS:
        return {"ok": True, "format": "GeoTIFF/TIFF", "error": None}
    if ext in BENCHMARK_EXTS:
        if _in_benchmark_dir(path):
            return {"ok": True, "format": "PNG/JPEG", "error": None}
        return {"ok": False, "format": "PNG/JPEG",
                "error": f"E_FORMAT: PNG/JPEG allowed only for benchmark datasets ({'/'.join(BENCHMARK_ALLOWLIST_DIRS)})."}
    return {"ok": False, "format": "UNKNOWN",
            "error": f"E_FORMAT: unsupported extension '{ext}'. Use GeoTIFF/TIFF."}


# ---------------------------------------------------------------------------
# Modality detection (heuristic; deterministic)
# ---------------------------------------------------------------------------

_SAR_KEYWORDS = re.compile(r"sar|risat|sentinel1|\bs1\b|backscatter|sigma|amplitude", re.I)


def detect_modality(path: str) -> str:
    """Return 'optical' or 'sar'."""
    name = os.path.basename(path) + " " + (os.path.basename(os.path.dirname(path)) if os.path.dirname(path) else "")
    if _SAR_KEYWORDS.search(name):
        return "sar"
    return "optical"


def _bands(path: str) -> Optional[int]:
    try:
        with Image.open(path) as im:
            m = im.mode
            return {"RGB": 3, "RGBA": 4, "L": 1}[m] if m in ("RGB", "RGBA", "L") else im.bands
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Pair inference (type + compatibility)
# ---------------------------------------------------------------------------

def infer_pair(files: List[dict]) -> Dict[str, object]:
    """Determine pair type and run compatibility/co-registration checks."""
    mods = [f["modality"] for f in files]
    dates = [f.get("date") for f in files]
    same_modality = len(set(mods)) == 1

    if len(files) == 1:
        return {"type": ("single_sar" if mods[0] == "sar" else "single_optical"),
                "overlap": 1.0, "offset_px": 0.0, "dt_days": 0, "actions": []}

    if same_modality and mods[0] == "optical":
        # Bi-temporal if 2 optical with different dates (or unknown -> assume).
        dt = _days_between(dates[0], dates[1]) if all(dates) else None
        return {"type": "bi_temporal", "overlap": 1.0, "offset_px": 0.0,
                "dt_days": dt, "actions": [], "dates": dates}

    if not same_modality and "sar" in mods and "optical" in mods and len(files) == 2:
        return {"type": "cross_modal", "overlap": 1.0, "offset_px": 0.0,
                "dt_days": 0, "actions": [], "dates": dates}

    return {"type": "invalid", "overlap": 0.0, "offset_px": None,
            "dt_days": None, "actions": [],
            "error": "E_PAIR_MISMATCH: combination of modalities/dates does not form a supported pair."}


def _days_between(a: str, b: str) -> Optional[int]:
    from datetime import date
    try:
        da = date.fromisoformat(a)
        db = date.fromisoformat(b)
        return abs((db - da).days)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Tiling (stub — real tiling with geotransforms comes with GDAL; see WITH_GDAL)
# ---------------------------------------------------------------------------

def tile_plan(path: str, tile: int = 512, overlap: int = 64) -> Dict[str, object]:
    try:
        with Image.open(path) as im:
            w, h = im.size
    except Exception:
        w, h = 1024, 1024
    step = tile - overlap
    cols = max(1, (w + step - 1) // step)
    rows = max(1, (h + step - 1) // step)
    return {"tile": tile, "overlap": overlap, "cols": cols, "rows": rows,
            "num_tiles": int(cols * rows), "too_large": max(w, h) > 65000}


# ---------------------------------------------------------------------------
# Top-level entry
# ---------------------------------------------------------------------------

def build_inventory(files: List[dict], request_id: str, tile: int = 512) -> dict:
    """files: list of {'path', 'name', 'date'?}. Returns an Input Inventory dict."""
    records: List[dict] = []
    for f in files:
        path = f["path"]
        fmt = validate_format(path)
        if not fmt["ok"]:
            # Surface a reject card for the offending file.
            return {"_error": fmt["error"], "request_id": request_id, "files": [], "pair": {}}
        bands = _bands(path)
        modality = detect_modality(path)
        try:
            with Image.open(path) as im:
                w, h = im.size
        except Exception:
            w, h = 0, 0
        records.append({
            "name": f.get("name", os.path.basename(path)),
            "path": path, "format": fmt["format"], "crs": None,
            "extent": None, "res_m": None, "size_px": [w, h],
            "bands": bands, "band_roles": None, "modality": modality,
            "date": f.get("date"),
            "tiles": tile_plan(path, tile)["num_tiles"],
            "sha256": _sha256(path),
        })

    pair = infer_pair(records)
    return {
        "request_id": request_id,
        "files": records,
        "pair": pair,
        "gdal": {"available": HAS_RASTERIO, "note": None if HAS_RASTERIO
                 else "GDAL/rasterio not installed: CRS/extent/coreg checks degraded (plug in rasterio for real GeoTIFFs)."},
    }


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
    except Exception:
        pass
    return h.hexdigest()[:16]
