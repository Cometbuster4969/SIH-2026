# SatQuery AI — runnable agentic skeleton (Phase 1 / round-1 prototype)

A working end-to-end scaffold for the **agentic remote-sensing question-answering**
system (SIH PS 26167, ISRO). It demonstrates the **graded novelty** — agent
selects/sequences specialist tools from a **predefined registry**, executes them,
and returns an answer with an **auditable execution trace**, per-tool **confidence**,
**visual evidence** and a downloadable **trace.json** report — **with no ML training
required.** The stub tools return deterministic, structured outputs so every PS query
flows end-to-end before any model weights exist.

> This matches `proposedidea.md`: the graded surface (agent + trace + registry +
> confidence + evidence) is fully real; the specialist models (M1–M7) are plugged in
> during Phase 2 post-selection. Nothing here fakes a trained baseline.

## Run it

```bash
cd satquery
pip install -r requirements.txt

# one command:
python -m demo.generate_demo          # creates demo scene TIFFs (idempotent)
python -m uvicorn backend.api.app:app --host 0.0.0.0 --port 8000
```

Then open **http://localhost:8000** (frontend) → **Load demo scene** → ask any of the
guided queries. Or drive the API directly (`python smoketest.py`).

## Run the tests

```bash
python -m pytest -q        # 22 tests: registry, planner, guardrail, fallback,
                           # executor, orchestrator, confidence, API flow
```

## API

| Endpoint | What it does |
|---|---|
| `GET  /api/v1/tools` | Dump the predefined tool registry (proves "predefined registry") |
| `POST /api/v1/demo/load` | Load a curated demo bi-temporal pair (no file upload needed) |
| `POST /api/v1/ingest` | Upload 1–2 files → inventory (format/CRS/modality/pair checks) |
| `POST /api/v1/query` | `{request_id, query}` → run the agent, full result + trace |
| `GET  /api/v1/requests/{id}/trace.json` | Auditable execution trace (graded artifact) |
| `POST /api/v1/warmup` | Phase-2: loads all weights (no-op in skeleton) |
| `/health` `/version` | Ops |

Trace SQLite store defaults to `data/traces.db` (override via `SATQUERY_DB`).

## Architecture (where things live)

```
backend/
├── agent/
│   ├── registry.py    # tool registry + task taxonomy + scope rules + canonical plans
│   ├── schemas.py     # Plan / Step / ToolOutput / TraceRow (pydantic)
│   ├── planner.py     # Intent+task inference; RulePlanner (deterministic) + LLMPlanner hook
│   ├── guardrail.py   # scope check, registry check, param whitelist, cycle check
│   ├── rulerouter.py  # deterministic fallback (stamps fallback_used=true)
│   ├── executor.py    # DAG run, per-step timeout + retry, degrade (never crashes)
│   └── integrator.py  # final answer from tool outputs + confidence aggregation/badges
├── tools/             # stub implementations (the ONLY file to replace with real models)
├── ingestion/validate.py  # format gate, modality detection, pair inference, tiling
├── store/trace.py     # SQLite durable trace
└── api/app.py         # FastAPI routes + WebSocket stream + static frontend
frontend/index.html    # single-file console (no CDN, works offline)
demo/generate_demo.py  # demo scene generator (saves TIFF stand-ins)
tests/                 # unit + integration
```

## What you must replace to go from stub → real (Phase 2)

All in `backend/tools/__init__.py` (marked `TOREPLACE`). Keep the **input/output keys
and version strings identical** — the executor, trace and eval depend only on those:

| Tool | Replace with |
|---|---|
| `vqa` / `caption` | Qwen2-VL-2B (or InternVL2.5) LoRA on BigEarthNet.txt + VRSBench + RSVQA |
| `ground` | Grounding-DINO-T fine-tuned on VRSBench refs + BE.txt referring |
| `change_map` | BiT/ChangeFormer on QAG-360K + CDVQA + LEVIR-CD |
| `change_vqa` | M1 2-image head on CDVQA + QAG-360K + ChangeChat-105k |
| `xmodal_caption` / `xmodal_vqa` | M6 dual-tower fusion (or M1 2-image mode) on BE.txt S1–S2 + TAMMI |
| `xmodal_mask` | dual UNet++ (see M7 patch-classifier reframe in `proposedidea.md`) |
| `integrate` | LLM integrator (M2) — keep the "answer ONLY from tool outputs" rule |

## Key design guarantees

- **Never crashes on a bad plan** — any invalid plan routes to the rule fallback
  router; incompatibility yields a polite reject card with a reason + fix.
- **Param whitelist enforced** (PS A2.4) — only whitelisted params get executed.
- **Full trace** persisted for every DONE request (task, tools, params, input hashes,
  output summary, confidence, latency).
- **Offline-first** — no CDN/fonts/telemetry in the frontend; weights vendored in Phase 2.
